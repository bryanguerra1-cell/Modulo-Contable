CREATE DATABASE IF NOT EXISTS modulo_contable;
USE modulo_contable;

CREATE TABLE catalogo_cuentas (
    codigo_cuenta VARCHAR(10) PRIMARY KEY,
    nombre_cuenta VARCHAR(150) NOT NULL,
    nivel INT NOT NULL,
    codigo_padre VARCHAR(10),
    naturaleza CHAR(1) NOT NULL,
    FOREIGN KEY (codigo_padre) REFERENCES catalogo_cuentas(codigo_cuenta)
);

CREATE TABLE asiento (
    id_asiento INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    concepto VARCHAR(255) NOT NULL
);

CREATE TABLE detalle_asiento (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_asiento INT NOT NULL,
    codigo_cuenta VARCHAR(10) NOT NULL,
    debe DECIMAL(12,2) NOT NULL DEFAULT 0,
    haber DECIMAL(12,2) NOT NULL DEFAULT 0,
    FOREIGN KEY (id_asiento) REFERENCES asiento(id_asiento),
    FOREIGN KEY (codigo_cuenta) REFERENCES catalogo_cuentas(codigo_cuenta)
);