USE modulo_contable;

-- ==========================================
-- 1. ACTIVO
-- ==========================================
INSERT INTO catalogo_cuentas (codigo_cuenta, nombre_cuenta, nivel, codigo_padre, naturaleza) VALUES
('1', 'ACTIVO', 1, NULL, 'D'),
('11', 'ACTIVO CORRIENTE', 2, '1', 'D'),
('1101', 'EFECTIVO Y EQUIVALENTES DE EFECTIVO', 4, '11', 'D'),
('110101', 'CAJA', 6, '1101', 'D'),
('110102', 'BANCOS MONEDA NACIONAL', 6, '1101', 'D'),
('11010201', 'CUENTA CORRIENTE', 8, '110102', 'D'),
('11010202', 'CUENTA DE AHORRO', 8, '110102', 'D'),
('110103', 'BANCOS MONEDA EXTRANJERA', 6, '1101', 'D'),
('11010301', 'CUENTA CORRIENTE', 8, '110103', 'D'),
('11010302', 'CUENTA DE AHORRO', 8, '110103', 'D'),
('1102', 'CUENTAS Y DOCUMENTOS POR COBRAR', 4, '11', 'D'),
('110201', 'CUENTAS POR COBRAR CREDITOS OTORGADOS', 6, '1102', 'D'),
('110202', 'OTRAS CUENTAS POR COBRAR', 6, '1102', 'D'),
('110203', 'PRESTAMOS A FUNCIONARIOS Y EMPLEADOS', 6, '1102', 'D'),
('110204', 'DOCUMENTOS POR COBRAR', 6, '1102', 'D'),
('1103', 'ESTIMACION PARA CUENTAS INCOBRABLES (CR)', 4, '11', 'A'),
('1104', 'INVERSIONES A CORTO PLAZO', 4, '11', 'D'),
('1105', 'INVENTARIOS', 4, '11', 'D'),
('1106', 'ACCIONISTAS', 4, '11', 'D'),
('1107', 'GASTOS PAGADOS POR ANTICIPADO', 4, '11', 'D'),
('110701', 'Seguros pagados por anticipado', 6, '1107', 'D'),
('110702', 'Alquileres pagados por anticipado', 6, '1107', 'D'),
('110703', 'Papeleria y utiles', 6, '1107', 'D'),
('110704', 'Uniformes y equipo', 6, '1107', 'D'),
('110705', 'Contratos por servicios', 6, '1107', 'D'),
('110706', 'Otros gastos pagados por anticipado', 6, '1107', 'D'),
('1108', 'PAGO A CUENTA - ISR', 4, '11', 'D'),
('1109', 'CREDITO FISCAL - IVA', 4, '11', 'D'),
('12', 'ACTIVO NO CORRIENTE', 2, '1', 'D'),
('1201', 'PROPIEDADES, PLANTA Y EQUIPO', 4, '12', 'D'),
('120101', 'Terrenos', 6, '1201', 'D'),
('120102', 'Edificios', 6, '1201', 'D'),
('120103', 'MOBILIARIO Y EQUIPO', 6, '1201', 'D'),
('12010301', 'Mobiliario y equipo de Oficina', 8, '120103', 'D'),
('12010302', 'Equipo de computo', 8, '120103', 'D'),
('120104', 'Herramientas y equipos', 6, '1201', 'D'),
('120106', 'Equipo de transporte', 6, '1201', 'D'),
('120107', 'CONSTRUCCIONES EN PROCESO', 6, '1201', 'D'),
('120108', 'DEPRECIACION ACUMULADA - PPE (CR)', 6, '1201', 'A'),
('1203', 'PROPIEDADES DE INVERSION', 4, '12', 'D'),
('1204', 'INTANGIBLES', 4, '12', 'D'),
('1205', 'CUENTAS POR COBRAR A LARGO PLAZO', 4, '12', 'D'),
('1206', 'INVERSIONES PERMANENTES', 4, '12', 'D'),
('1207', 'DEPOSITOS EN GARANTIA', 4, '12', 'D'),
('1208', 'ISR DIFERIDO - ACTIVO', 4, '12', 'D'),
('1209', 'OTRAS CUENTAS DEUDORAS', 4, '12', 'D');

-- ==========================================
-- 2. PASIVO
-- ==========================================
INSERT INTO catalogo_cuentas (codigo_cuenta, nombre_cuenta, nivel, codigo_padre, naturaleza) VALUES
('2', 'PASIVO', 1, NULL, 'A'),
('21', 'PASIVO CORRIENTE', 2, '2', 'A'),
('2101', 'PRESTAMOS A CORTO PLAZO Y SOBREGIROS', 4, '21', 'A'),
('210102', 'Prestamos bancarios (porcion a corto plazo)', 6, '2101', 'A'),
('2102', 'CUENTAS COMERCIALES POR PAGAR', 4, '21', 'A'),
('210201', 'PROVEEDORES POR PAGAR', 6, '2102', 'A'),
('21020101', 'PROVEEDORES NACIONALES', 8, '210201', 'A'),
('21020103', 'PROVEEDORES DEL EXTERIOR', 8, '210201', 'A'),
('210202', 'DOCUMENTOS POR PAGAR', 6, '2102', 'A'),
('2103', 'ACREEDORES VARIOS', 4, '21', 'A'),
('2104', 'RETENCIONES POR PAGAR', 4, '21', 'A'),
('2105', 'BENEFICIOS A EMPLEADOS POR PAGAR', 4, '21', 'A'),
('2106', 'IMPUESTO SOBRE LA RENTA POR PAGAR', 4, '21', 'A'),
('210602', 'Pago a cuenta', 6, '2106', 'A'),
('2107', 'OBLIGACIONES POR ARRENDAMIENTO FINANCIERO', 4, '21', 'A'),
('2108', 'IVA - DEBITO FISCAL', 4, '21', 'A'),
('2109', 'CUENTAS POR PAGAR COMPANIAS RELACIONADAS Y ACCIONISTAS', 4, '21', 'A'),
('2110', 'DIVIDENDOS POR PAGAR', 4, '21', 'A'),
('22', 'PASIVO NO CORRIENTE', 2, '2', 'A'),
('2201', 'PRESTAMOS POR PAGAR A LARGO PLAZO', 4, '22', 'A'),
('220101', 'Prestamos bancarios (Porcion a largo plazo)', 6, '2201', 'A'),
('2202', 'OBLIGACIONES POR ARRENDAMIENTO FINANCIERO', 4, '22', 'A'),
('2203', 'BENEFICIOS POR PAGAR A EMPLEADOS - LARGO PLAZO', 4, '22', 'A'),
('2204', 'ISR DIFERIDO - PASIVO', 4, '22', 'A');

-- ==========================================
-- 3. PATRIMONIO
-- ==========================================
INSERT INTO catalogo_cuentas (codigo_cuenta, nombre_cuenta, nivel, codigo_padre, naturaleza) VALUES
('3', 'PATRIMONIO', 1, NULL, 'A'),
('31', 'CAPITAL Y RESERVAS', 2, '3', 'A'),
('3101', 'CAPITAL SOCIAL', 4, '31', 'A'),
('310101', 'CAPITAL SOCIAL MINIMO', 6, '3101', 'A'),
('310102', 'CAPITAL SOCIAL VARIABLE', 6, '3101', 'A'),
('3102', 'RESERVA LEGAL', 4, '31', 'A'),
('3103', 'SUPERAVIT POR REVALUACIONES', 4, '31', 'A'),
('32', 'RESULTADOS POR APLICAR', 2, '3', 'A'),
('3201', 'UTILIDADES DE EJERCICIOS ANTERIORES', 4, '32', 'A'),
('3202', 'UTILIDAD DEL PRESENTE EJERCICIO', 4, '32', 'A'),
('3203', 'DEFICIT DE EJERCICIOS ANTERIORES', 4, '32', 'D'),
('3204', 'DEFICIT DEL PRESENTE EJERCICIO', 4, '32', 'D');

-- ==========================================
-- 4. CUENTAS DE RESULTADO DEUDORAS
-- ==========================================
INSERT INTO catalogo_cuentas (codigo_cuenta, nombre_cuenta, nivel, codigo_padre, naturaleza) VALUES
('4', 'CUENTAS DE RESULTADO DEUDORAS', 1, NULL, 'D'),
('41', 'COSTOS Y GASTOS DE OPERACION', 2, '4', 'D'),
('4101', 'COSTO DE VENTAS', 4, '41', 'D'),
('4102', 'GASTOS ADMINISTRATIVOS', 4, '41', 'D'),
('410201', 'GASTOS DE PERSONAL', 6, '4102', 'D'),
('41020101', 'Salarios', 8, '410201', 'D'),
('41020102', 'Vacaciones', 8, '410201', 'D'),
('41020103', 'Aguinaldos', 8, '410201', 'D'),
('41020104', 'Bonificaciones y gratificaciones', 8, '410201', 'D'),
('41020105', 'Horas extras', 8, '410201', 'D'),
('41020106', 'Indemnizaciones', 8, '410201', 'D'),
('41020107', 'Viaticos', 8, '410201', 'D'),
('410202', 'GASTOS DE MANTENIMIENTO', 6, '4102', 'D'),
('410203', 'GASTOS POR SERVICIOS PUBLICOS Y PRIVADOS', 6, '4102', 'D'),
('41020301', 'Servicio de agua', 8, '410203', 'D'),
('41020302', 'Servicio de energia electrica', 8, '410203', 'D'),
('41020303', 'Servicio de Telefono', 8, '410203', 'D'),
('41020304', 'Servicio de internet/cable', 8, '410203', 'D'),
('41020305', 'Servicio de vigilancia', 8, '410203', 'D'),
('41020306', 'Publicidad y promocion', 8, '410203', 'D'),
('41020307', 'Impresiones y Encuadernaciones', 8, '410203', 'D'),
('41020308', 'Suscripciones periodicos y Revistas', 8, '410203', 'D'),
('41020309', 'Servicios de limpieza y Ornamentacion', 8, '410203', 'D'),
('41020310', 'Otros servicios', 8, '410203', 'D'),
('410204', 'HONORARIOS PROFESIONALES', 6, '4102', 'D'),
('410205', 'GASTOS POR DEPRECIACION', 6, '4102', 'D'),
('410206', 'GASTOS POR AMORTIZACION', 6, '4102', 'D'),
('410207', 'GASTOS POR SEGUROS', 6, '4102', 'D'),
('410208', 'GASTOS POR IMPUESTOS, TASAS MUNICIPALES Y OTRAS CONTRIBUCIONES', 6, '4102', 'D'),
('410209', 'GASTOS A CLIENTES Y EMPLEADOS', 6, '4102', 'D'),
('410210', 'GASTOS DE VIATICOS, VIAJES Y DE REPRESENTACION', 6, '4102', 'D'),
('4103', 'GASTOS DE VENTA', 4, '41', 'D'),
('410301', 'GASTOS DE PERSONAL', 6, '4103', 'D'),
('410302', 'GASTOS DE MANTENIMIENTO', 6, '4103', 'D'),
('410303', 'GASTOS POR SERVICIOS PUBLICOS Y PRIVADOS', 6, '4103', 'D'),
('410304', 'HONORARIOS PROFESIONALES', 6, '4103', 'D'),
('410305', 'GASTOS POR DEPRECIACION', 6, '4103', 'D'),
('410306', 'GASTOS POR AMORTIZACION', 6, '4103', 'D'),
('410307', 'GASTOS POR SEGUROS', 6, '4103', 'D'),
('410308', 'GASTOS POR IMPUESTOS, TASAS MUNICIPALES Y OTRAS CONTRIBUCIONES', 6, '4103', 'D'),
('410309', 'ATENCION A EMPLEADOS', 6, '4103', 'D'),
('410310', 'GASTOS DE VIATICOS, VIAJES Y DE REPRESENTACION', 6, '4103', 'D'),
('42', 'OTROS COSTOS Y GASTOS', 2, '4', 'D'),
('4201', 'GASTOS FINANCIEROS', 4, '42', 'D'),
('420101', 'Intereses sobre prestamos', 6, '4201', 'D'),
('420102', 'Comisiones', 6, '4201', 'D'),
('420103', 'Seguros', 6, '4201', 'D'),
('420104', 'Impuesto a las Operaciones Financieras', 6, '4201', 'D'),
('4202', 'PERDIDA EN VENTA O RETIRO DE ACTIVOS FIJOS', 4, '42', 'D'),
('4203', 'GASTOS POR DETERIORO EN EL VALOR DE ACTIVOS', 4, '42', 'D'),
('4204', 'PERDIDAS POR SINIESTROS', 4, '42', 'D'),
('4205', 'GASTOS DE EJERCICIOS ANTERIORES', 4, '42', 'D'),
('4206', 'OTROS GASTOS', 4, '42', 'D');

-- ==========================================
-- 5. CUENTAS DE RESULTADO ACREEDORAS
-- ==========================================
INSERT INTO catalogo_cuentas (codigo_cuenta, nombre_cuenta, nivel, codigo_padre, naturaleza) VALUES
('5', 'CUENTAS DE RESULTADO ACREEDORAS', 1, NULL, 'A'),
('51', 'INGRESOS POR VENTAS', 2, '5', 'A'),
('5101', 'INGRESOS OPERACIONALES', 4, '51', 'A'),
('510101', 'VENTAS LOCALES SALA DE VENTAS 01', 6, '5101', 'A'),
('51010101', 'Ventas a contribuyentes', 8, '510101', 'A'),
('51010102', 'Ventas a consumidor final', 8, '510101', 'A'),
('510104', 'REBAJAS Y DEVOLUCIONES SOBRE VENTAS', 6, '5101', 'D'),
('51010401', 'Rebajas sobre ventas', 8, '510104', 'D'),
('51010402', 'Devoluciones sobre ventas', 8, '510104', 'D'),
('52', 'OTROS PRODUCTOS', 2, '5', 'A'),
('5201', 'PRODUCTOS FINANCIEROS', 4, '52', 'A'),
('5202', 'GANANCIA EN VENTA DE ACTIVOS FIJOS', 4, '52', 'A'),
('5204', 'OTROS PRODUCTOS', 4, '52', 'A');

-- ==========================================
-- 6. CUENTA DE CIERRE
-- ==========================================
INSERT INTO catalogo_cuentas (codigo_cuenta, nombre_cuenta, nivel, codigo_padre, naturaleza) VALUES
('6', 'CUENTA DE CIERRE', 1, NULL, 'D'),
('61', 'CUENTA LIQUIDADORA', 2, '6', 'D'),
('6101', 'PERDIDAS Y GANANCIAS', 4, '61', 'D');

-- ==========================================
-- 7. CUENTAS DE ORDEN
-- ==========================================
INSERT INTO catalogo_cuentas (codigo_cuenta, nombre_cuenta, nivel, codigo_padre, naturaleza) VALUES
('7', 'CUENTAS DE ORDEN', 1, NULL, 'D'),
('71', 'CUENTAS DE ORDEN', 2, '7', 'D'),
('7101', 'CUENTAS DE ORDEN POR DERECHOS CONTINGENTES', 4, '71', 'D'),
('7102', 'CUENTAS DE ORDEN POR RESPONSABILIDADES CONTINGENTES', 4, '71', 'D'),
('72', 'CUENTAS DE ORDEN POR CONTRA', 2, '7', 'A'),
('7201', 'CUENTAS DE ORDEN POR DERECHOS CONTINGENTES - POR CONTRA', 4, '72', 'A'),
('7202', 'CUENTAS DE ORDEN POR RESPONSABILIDADES CONTINGENTES - POR EL CONTRARIO', 4, '72', 'A');