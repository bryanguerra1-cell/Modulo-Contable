/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.modulocontable;

import com.modulocontable.conexion.Conexion;
import com.modulocontable.vista.Pantalla;
import java.sql.Connection;

/**
 *
 * @author jorge
 */
public class ModuloContable {

    public static void main(String[] args) {
        try {
            Connection con = Conexion.getConexion();
            if (con != null && !con.isClosed()) {
                System.out.println("✅ Conexión exitosa a la base de datos modulo_contable");
            }
        } catch (Exception e) {
            System.out.println("❌ Error de conexión: " + e.getMessage());
        }
        
        javax.swing.JFrame.setDefaultLookAndFeelDecorated(true);
        
        try {
            com.formdev.flatlaf.FlatLightLaf.setup();
        } catch( Exception ex ) {
            System.err.println( "Failed to initialize LaF" );
        }

        // 2. Crear y mostrar el JFrame
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Pantalla ventana = new Pantalla();
                ventana.setVisible(true);
            }
        });
    }
}
