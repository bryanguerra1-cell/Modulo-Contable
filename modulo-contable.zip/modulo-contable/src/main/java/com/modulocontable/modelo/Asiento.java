/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.modulocontable.modelo;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class Asiento {

    private int idAsiento;
    private Date fecha;
    private String concepto;
    private List<DetalleAsiento> detalles = new ArrayList<>();

    public Asiento() {
    }

    public Asiento(Date fecha, String concepto) {
        this.fecha = fecha;
        this.concepto = concepto;
    }

    public int getIdAsiento() { return idAsiento; }
    public void setIdAsiento(int idAsiento) { this.idAsiento = idAsiento; }

    public Date getFecha() { return fecha; }
    public void setFecha(Date fecha) { this.fecha = fecha; }

    public String getConcepto() { return concepto; }
    public void setConcepto(String concepto) { this.concepto = concepto; }

    public List<DetalleAsiento> getDetalles() { return detalles; }
    public void setDetalles(List<DetalleAsiento> detalles) { this.detalles = detalles; }

    public void agregarDetalle(DetalleAsiento detalle) {
        this.detalles.add(detalle);
    }
}
