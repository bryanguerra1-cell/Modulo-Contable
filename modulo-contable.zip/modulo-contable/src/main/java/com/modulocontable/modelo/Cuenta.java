/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.modulocontable.modelo;

public class Cuenta {

    private String codigoCuenta;
    private String nombreCuenta;
    private int nivel;
    private String codigoPadre;
    private char naturaleza; // 'D' o 'A'

    public Cuenta() {
    }

    public Cuenta(String codigoCuenta, String nombreCuenta, int nivel, String codigoPadre, char naturaleza) {
        this.codigoCuenta = codigoCuenta;
        this.nombreCuenta = nombreCuenta;
        this.nivel = nivel;
        this.codigoPadre = codigoPadre;
        this.naturaleza = naturaleza;
    }

    public String getCodigoCuenta() { return codigoCuenta; }
    public void setCodigoCuenta(String codigoCuenta) { this.codigoCuenta = codigoCuenta; }

    public String getNombreCuenta() { return nombreCuenta; }
    public void setNombreCuenta(String nombreCuenta) { this.nombreCuenta = nombreCuenta; }

    public int getNivel() { return nivel; }
    public void setNivel(int nivel) { this.nivel = nivel; }

    public String getCodigoPadre() { return codigoPadre; }
    public void setCodigoPadre(String codigoPadre) { this.codigoPadre = codigoPadre; }

    public char getNaturaleza() { return naturaleza; }
    public void setNaturaleza(char naturaleza) { this.naturaleza = naturaleza; }

    // Clasificación automática por primer dígito del código (para Balance/Estado de Resultados)
    public int getClasificacionGeneral() {
        return Character.getNumericValue(codigoCuenta.charAt(0));
    }

    @Override
    public String toString() {
        return codigoCuenta + " - " + nombreCuenta; // útil para mostrar en JComboBox
    }
}
