/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.modulocontable.modelo;

import java.math.BigDecimal;

public class DetalleAsiento {

    private int idDetalle;
    private int idAsiento;
    private String codigoCuenta;
    private String nombreCuenta; // para mostrar en la tabla, no se guarda en detalle_asiento
    private BigDecimal debe;
    private BigDecimal haber;

    public DetalleAsiento() {
        this.debe = BigDecimal.ZERO;
        this.haber = BigDecimal.ZERO;
    }

    public DetalleAsiento(String codigoCuenta, BigDecimal debe, BigDecimal haber) {
        this.codigoCuenta = codigoCuenta;
        this.debe = debe;
        this.haber = haber;
    }

    public int getIdDetalle() { return idDetalle; }
    public void setIdDetalle(int idDetalle) { this.idDetalle = idDetalle; }

    public int getIdAsiento() { return idAsiento; }
    public void setIdAsiento(int idAsiento) { this.idAsiento = idAsiento; }

    public String getCodigoCuenta() { return codigoCuenta; }
    public void setCodigoCuenta(String codigoCuenta) { this.codigoCuenta = codigoCuenta; }

    public String getNombreCuenta() { return nombreCuenta; }
    public void setNombreCuenta(String nombreCuenta) { this.nombreCuenta = nombreCuenta; }

    public BigDecimal getDebe() { return debe; }
    public void setDebe(BigDecimal debe) { this.debe = debe; }

    public BigDecimal getHaber() { return haber; }
    public void setHaber(BigDecimal haber) { this.haber = haber; }
}
