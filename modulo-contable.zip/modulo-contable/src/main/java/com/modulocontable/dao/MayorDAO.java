package com.modulocontable.dao;

import com.modulocontable.conexion.Conexion;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MayorDAO {

    public List<Object[]> obtenerMovimientosPorCuenta(String codigoCuenta) throws SQLException {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT a.id_asiento, a.fecha, a.concepto, d.debe, d.haber " +
                     "FROM detalle_asiento d " +
                     "INNER JOIN asiento a ON d.id_asiento = a.id_asiento " +
                     "WHERE d.codigo_cuenta = ? " +
                     "ORDER BY a.fecha ASC, a.id_asiento ASC";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigoCuenta);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Object[]{
                        rs.getInt("id_asiento"),
                        rs.getDate("fecha"),
                        rs.getString("concepto"),
                        rs.getBigDecimal("debe"),
                        rs.getBigDecimal("haber")
                    });
                }
            }
        }
        return lista;
    }
}