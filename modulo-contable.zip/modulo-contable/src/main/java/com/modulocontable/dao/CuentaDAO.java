/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.modulocontable.dao;

import com.modulocontable.conexion.Conexion;
import com.modulocontable.modelo.Cuenta;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CuentaDAO {

    public List<Cuenta> listarTodas() throws SQLException {
        List<Cuenta> lista = new ArrayList<>();
        String sql = "SELECT codigo_cuenta, nombre_cuenta, nivel, codigo_padre, naturaleza FROM catalogo_cuentas ORDER BY codigo_cuenta";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Cuenta c = new Cuenta();
                c.setCodigoCuenta(rs.getString("codigo_cuenta"));
                c.setNombreCuenta(rs.getString("nombre_cuenta"));
                c.setNivel(rs.getInt("nivel"));
                c.setCodigoPadre(rs.getString("codigo_padre"));
                c.setNaturaleza(rs.getString("naturaleza").charAt(0));
                lista.add(c);
            }
        }
        return lista;
    }

    // Solo cuentas de detalle (nivel 6 u 8) — las que realmente se usan en asientos,
    // no las de agrupación (1,2,4 dígitos)
    public List<Cuenta> listarCuentasImputables() throws SQLException {
        List<Cuenta> lista = new ArrayList<>();
        String sql = "SELECT codigo_cuenta, nombre_cuenta, nivel, codigo_padre, naturaleza " +
                     "FROM catalogo_cuentas WHERE nivel >= 6 ORDER BY codigo_cuenta";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Cuenta c = new Cuenta();
                c.setCodigoCuenta(rs.getString("codigo_cuenta"));
                c.setNombreCuenta(rs.getString("nombre_cuenta"));
                c.setNivel(rs.getInt("nivel"));
                c.setCodigoPadre(rs.getString("codigo_padre"));
                c.setNaturaleza(rs.getString("naturaleza").charAt(0));
                lista.add(c);
            }
        }
        return lista;
    }
    
    // En CuentaDAO.java

    public boolean tieneHijos(String codigo) throws SQLException {
        String sql = "SELECT COUNT(*) FROM catalogo_cuentas WHERE codigo_padre = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigo);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    public boolean tieneMovimientos(String codigo) throws SQLException {
        String sql = "SELECT COUNT(*) FROM detalle_asiento WHERE codigo_cuenta = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigo);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    public void eliminar(String codigo) throws SQLException {
        String sql = "DELETE FROM catalogo_cuentas WHERE codigo_cuenta = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigo);
            ps.executeUpdate();
        }
    }

    public void insertar(Cuenta c) throws SQLException {
        String sql = "INSERT INTO catalogo_cuentas (codigo_cuenta, nombre_cuenta, nivel, codigo_padre, naturaleza) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getCodigoCuenta());
            ps.setString(2, c.getNombreCuenta());
            ps.setInt(3, c.getNivel());
            ps.setString(4, c.getCodigoPadre());
            ps.setString(5, String.valueOf(c.getNaturaleza()));
            ps.executeUpdate();
        }
    }

    public boolean existeCodigo(String codigo) throws SQLException {
        String sql = "SELECT COUNT(*) FROM catalogo_cuentas WHERE codigo_cuenta = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigo);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }
}
