/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.modulocontable.dao;

import com.modulocontable.conexion.Conexion;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InicioDAO {

    public int contarCuentasActivas() throws SQLException {
        String sql = "SELECT COUNT(*) FROM catalogo_cuentas WHERE nivel >= 6";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public int contarAsientosCreados() throws SQLException {
        String sql = "SELECT COUNT(*) FROM asiento";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public BigDecimal calcularVentasDelMes() throws SQLException {
        String sql = "SELECT COALESCE(SUM(d.haber) - SUM(d.debe), 0) AS ventas " +
                     "FROM detalle_asiento d INNER JOIN asiento a ON d.id_asiento = a.id_asiento " +
                     "WHERE d.codigo_cuenta LIKE '5101%' " +
                     "AND MONTH(a.fecha) = MONTH(CURDATE()) AND YEAR(a.fecha) = YEAR(CURDATE())";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getBigDecimal(1) : BigDecimal.ZERO;
        }
    }

    // Retorna [totalDebe, totalHaber]
    public BigDecimal[] verificarPartidaDobleGlobal() throws SQLException {
        String sql = "SELECT COALESCE(SUM(debe),0), COALESCE(SUM(haber),0) FROM detalle_asiento";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return new BigDecimal[]{ rs.getBigDecimal(1), rs.getBigDecimal(2) };
            }
            return new BigDecimal[]{ BigDecimal.ZERO, BigDecimal.ZERO };
        }
    }

    public List<Object[]> obtenerUltimosAsientos(int limite) throws SQLException {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT a.fecha, a.concepto, SUM(d.debe) AS total_debe, SUM(d.haber) AS total_haber " +
                     "FROM asiento a INNER JOIN detalle_asiento d ON a.id_asiento = d.id_asiento " +
                     "GROUP BY a.id_asiento, a.fecha, a.concepto " +
                     "ORDER BY a.fecha DESC, a.id_asiento DESC LIMIT ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, limite);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Object[]{
                        rs.getDate("fecha"), rs.getString("concepto"),
                        rs.getBigDecimal("total_debe"), rs.getBigDecimal("total_haber")
                    });
                }
            }
        }
        return lista;
    }

    public List<Object[]> obtenerCuentasMasUsadas(int limite) throws SQLException {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT c.nombre_cuenta, COUNT(*) AS veces " +
                     "FROM detalle_asiento d INNER JOIN catalogo_cuentas c ON d.codigo_cuenta = c.codigo_cuenta " +
                     "GROUP BY d.codigo_cuenta, c.nombre_cuenta ORDER BY veces DESC LIMIT ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, limite);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Object[]{ rs.getString("nombre_cuenta"), rs.getInt("veces") });
                }
            }
        }
        return lista;
    }
}
