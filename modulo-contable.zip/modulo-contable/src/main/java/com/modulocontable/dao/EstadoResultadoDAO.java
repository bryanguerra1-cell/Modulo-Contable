package com.modulocontable.dao;

import com.modulocontable.conexion.Conexion;

import java.math.BigDecimal;
import java.sql.*;

public class EstadoResultadoDAO {

    // Suma el saldo (Haber - Debe) de todas las cuentas bajo un prefijo dado
    public BigDecimal sumarSaldoAcreedor(String prefijo) throws SQLException {
        return sumarSaldo(prefijo, false);
    }

    // Suma el saldo (Debe - Haber) de todas las cuentas bajo un prefijo dado
    public BigDecimal sumarSaldoDeudor(String prefijo) throws SQLException {
        return sumarSaldo(prefijo, true);
    }

    private BigDecimal sumarSaldo(String prefijo, boolean deudor) throws SQLException {
        String sql = deudor
            ? "SELECT COALESCE(SUM(debe - haber), 0) FROM detalle_asiento WHERE codigo_cuenta LIKE CONCAT(?, '%')"
            : "SELECT COALESCE(SUM(haber - debe), 0) FROM detalle_asiento WHERE codigo_cuenta LIKE CONCAT(?, '%')";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, prefijo);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getBigDecimal(1) : BigDecimal.ZERO;
            }
        }
    }
}