/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.modulocontable.dao;

import com.modulocontable.conexion.Conexion;
import com.modulocontable.modelo.Asiento;
import com.modulocontable.modelo.DetalleAsiento;
import com.modulocontable.negocio.PartidaDobleException;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AsientoDAO {

    public int guardar(Asiento asiento) throws SQLException, PartidaDobleException {

        // 1. Validar Partida Doble ANTES de tocar la base de datos
        validarPartidaDoble(asiento);

        String sqlAsiento = "INSERT INTO asiento (fecha, concepto) VALUES (?, ?)";
        String sqlDetalle = "INSERT INTO detalle_asiento (id_asiento, codigo_cuenta, debe, haber) VALUES (?, ?, ?, ?)";

        Connection con = Conexion.getConexion();

        try {
            con.setAutoCommit(false); // iniciamos la transacción

            int idAsientoGenerado;

            // 2. Insertar encabezado del asiento
            try (PreparedStatement psAsiento = con.prepareStatement(sqlAsiento, Statement.RETURN_GENERATED_KEYS)) {
                psAsiento.setDate(1, asiento.getFecha());
                psAsiento.setString(2, asiento.getConcepto());
                psAsiento.executeUpdate();

                try (ResultSet rs = psAsiento.getGeneratedKeys()) {
                    if (rs.next()) {
                        idAsientoGenerado = rs.getInt(1);
                    } else {
                        throw new SQLException("No se pudo obtener el ID del asiento generado.");
                    }
                }
            }

            // 3. Insertar cada línea del detalle
            try (PreparedStatement psDetalle = con.prepareStatement(sqlDetalle)) {
                for (DetalleAsiento d : asiento.getDetalles()) {
                    psDetalle.setInt(1, idAsientoGenerado);
                    psDetalle.setString(2, d.getCodigoCuenta());
                    psDetalle.setBigDecimal(3, d.getDebe());
                    psDetalle.setBigDecimal(4, d.getHaber());
                    psDetalle.addBatch();
                }
                psDetalle.executeBatch();
            }

            con.commit(); // todo salió bien: confirmamos
            asiento.setIdAsiento(idAsientoGenerado);
            return idAsientoGenerado;

        } catch (SQLException e) {
            con.rollback(); // algo falló: deshacemos todo
            throw e;
        } finally {
            con.setAutoCommit(true); // devolvemos la conexión a su modo normal
        }
    }
    
    // En AsientoDAO.java

    public List<Object[]> listarResumen() throws SQLException {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT a.id_asiento, a.fecha, a.concepto, " +
                     "SUM(d.debe) AS total_debe, SUM(d.haber) AS total_haber " +
                     "FROM asiento a INNER JOIN detalle_asiento d ON a.id_asiento = d.id_asiento " +
                     "GROUP BY a.id_asiento, a.fecha, a.concepto " +
                     "ORDER BY a.fecha DESC, a.id_asiento DESC";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new Object[]{
                    rs.getInt("id_asiento"),
                    rs.getDate("fecha"),
                    rs.getString("concepto"),
                    rs.getBigDecimal("total_debe"),
                    rs.getBigDecimal("total_haber")
                });
            }
        }
        return lista;
    }
    
    // En AsientoDAO.java

    public List<Object[]> obtenerDetallePorId(int idAsiento) throws SQLException {
        List<Object[]> lista = new ArrayList<>();
        String sql = "SELECT d.codigo_cuenta, c.nombre_cuenta, d.debe, d.haber " +
                     "FROM detalle_asiento d " +
                     "INNER JOIN catalogo_cuentas c ON d.codigo_cuenta = c.codigo_cuenta " +
                     "WHERE d.id_asiento = ? " +
                     "ORDER BY d.id_detalle";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idAsiento);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Object[]{
                        rs.getString("codigo_cuenta"),
                        rs.getString("nombre_cuenta"),
                        rs.getBigDecimal("debe"),
                        rs.getBigDecimal("haber")
                    });
                }
            }
        }
        return lista;
    }

    // También útil para el dialog: traer fecha y concepto del encabezado
    public Object[] obtenerEncabezadoPorId(int idAsiento) throws SQLException {
        String sql = "SELECT fecha, concepto FROM asiento WHERE id_asiento = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idAsiento);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Object[]{ rs.getDate("fecha"), rs.getString("concepto") };
                }
                return null;
            }
        }
    }

    private void validarPartidaDoble(Asiento asiento) throws PartidaDobleException {
        if (asiento.getDetalles() == null || asiento.getDetalles().size() < 2) {
            throw new PartidaDobleException("El asiento debe tener al menos 2 líneas (una cuenta al Debe y otra al Haber).");
        }

        BigDecimal totalDebe = BigDecimal.ZERO;
        BigDecimal totalHaber = BigDecimal.ZERO;

        for (DetalleAsiento d : asiento.getDetalles()) {
            totalDebe = totalDebe.add(d.getDebe());
            totalHaber = totalHaber.add(d.getHaber());
        }

        if (totalDebe.compareTo(totalHaber) != 0) {
            throw new PartidaDobleException(
                "El asiento no cuadra. Debe: " + totalDebe + "  Haber: " + totalHaber
            );
        }

        if (totalDebe.compareTo(BigDecimal.ZERO) == 0) {
            throw new PartidaDobleException("El asiento no puede tener montos en cero.");
        }
    }

    public List<Asiento> listarTodos() throws SQLException {
        List<Asiento> lista = new ArrayList<>();
        String sql = "SELECT id_asiento, fecha, concepto FROM asiento ORDER BY fecha, id_asiento";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Asiento a = new Asiento();
                a.setIdAsiento(rs.getInt("id_asiento"));
                a.setFecha(rs.getDate("fecha"));
                a.setConcepto(rs.getString("concepto"));
                lista.add(a);
            }
        }
        return lista;
    }
}
