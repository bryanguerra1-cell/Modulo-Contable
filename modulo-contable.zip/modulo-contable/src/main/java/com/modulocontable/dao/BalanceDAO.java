package com.modulocontable.dao;

import com.modulocontable.conexion.Conexion;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BalanceDAO {

    // Trae las cuentas de mayor (nivel 4) cuyo código empieza con el prefijo dado,
    // con su saldo ya calculado según naturaleza (sumando TODOS sus hijos imputables)
    public List<Object[]> obtenerCuentasPorPrefijo(String prefijo) throws SQLException {
        List<Object[]> lista = new ArrayList<>();
        String sql =
            "SELECT c.codigo_cuenta, c.nombre_cuenta, c.naturaleza, " +
            "COALESCE(SUM(CASE WHEN c.naturaleza = 'D' THEN d.debe - d.haber " +
            "                   ELSE d.haber - d.debe END), 0) AS saldo " +
            "FROM catalogo_cuentas c " +
            "LEFT JOIN detalle_asiento d ON d.codigo_cuenta LIKE CONCAT(c.codigo_cuenta, '%') " +
            "WHERE c.nivel = 4 AND c.codigo_cuenta LIKE CONCAT(?, '%') " +
            "GROUP BY c.codigo_cuenta, c.nombre_cuenta, c.naturaleza " +
            "ORDER BY c.codigo_cuenta";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, prefijo);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Object[]{
                        rs.getString("codigo_cuenta"),
                        rs.getString("nombre_cuenta"),
                        rs.getBigDecimal("saldo")
                    });
                }
            }
        }
        return lista;
    }
}