/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.modulocontable.vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BotonTablaEditor extends AbstractCellEditor implements javax.swing.table.TableCellEditor {

    private final JButton boton;
    private int idAsientoSeleccionado;
    private final DetalleClickListener listener;

    public interface DetalleClickListener {
        void onVerDetalle(int idAsiento);
    }

    public BotonTablaEditor(DetalleClickListener listener) {
        this.listener = listener;
        boton = new JButton("Ver Detalle");
        boton.addActionListener((ActionEvent e) -> {
            fireEditingStopped();
            listener.onVerDetalle(idAsientoSeleccionado);
        });
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value,
            boolean isSelected, int row, int column) {
        // Recuperamos el id_asiento guardado en una columna oculta (ver paso 3)
        DefaultTableModel modelo = (DefaultTableModel) table.getModel();
        idAsientoSeleccionado = (int) modelo.getValueAt(row, 0); // columna 0 = id oculto
        return boton;
    }

    @Override
    public Object getCellEditorValue() {
        return "Ver Detalle";
    }
}
