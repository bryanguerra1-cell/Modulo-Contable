/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.modulocontable.vista;

import com.modulocontable.modelo.Cuenta;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import java.awt.*;

public class CuentaTreeCellRenderer extends DefaultTreeCellRenderer {

    @Override
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected,
            boolean expanded, boolean leaf, int row, boolean hasFocus) {

        super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);

        DefaultMutableTreeNode nodo = (DefaultMutableTreeNode) value;
        Object userObject = nodo.getUserObject();

        if (userObject instanceof Cuenta) {
            Cuenta c = (Cuenta) userObject;
            setText(c.getCodigoCuenta() + "  -  " + c.getNombreCuenta());

            if (!selected) {
                if (c.getNivel() < 6) {
                    setFont(getFont().deriveFont(Font.BOLD));
                    setForeground(new Color(0, 100, 60));
                } else {
                    setFont(getFont().deriveFont(Font.PLAIN));
                    setForeground(Color.DARK_GRAY);
                }
            }
        }

        return this;
    }
}
