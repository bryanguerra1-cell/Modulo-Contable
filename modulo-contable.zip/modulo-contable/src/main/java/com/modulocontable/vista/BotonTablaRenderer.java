/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.modulocontable.vista;

import javax.swing.*;
import java.awt.*;

public class BotonTablaRenderer extends JButton implements javax.swing.table.TableCellRenderer {

    public BotonTablaRenderer() {
        setText("Ver Detalle");
        setOpaque(true);
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
            boolean isSelected, boolean hasFocus, int row, int column) {
        return this;
    }
}
